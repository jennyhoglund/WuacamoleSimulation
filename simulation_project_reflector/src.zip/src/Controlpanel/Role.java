package Controlpanel;

public enum Role {
    parent,
    leaf
}
