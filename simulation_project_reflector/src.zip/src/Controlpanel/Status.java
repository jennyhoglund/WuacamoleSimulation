package Controlpanel;

public enum Status {
    connected,
    idle
}
